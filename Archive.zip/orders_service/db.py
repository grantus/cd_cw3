"""
orders_service/db.py
SQLite helper used by the Orders service
----------------------------------------

* Creates the two tables the service needs:
    - orders      (business data)
    - outbox      (transactional-outbox rows)

* Guarantees the `sent` column exists in legacy databases so the
  outbox-relay thread can run without crashing.

The module initialises `conn` and `cursor` at import-time so other
modules can simply do:

    from db import conn, cursor
"""

from pathlib import Path
import sqlite3

# -------------------------------------------------
# Connection + cursor

db_file = Path(__file__).parent / "orders.db"

# check_same_thread=False lets background threads reuse the connection
conn = sqlite3.connect(db_file, check_same_thread=False)
conn.row_factory = sqlite3.Row            # nice dict-style rows
cursor = conn.cursor()

# -------------------------------------------------
# Schema (idempotent)

cursor.execute(
    """
    CREATE TABLE IF NOT EXISTS orders (
        order_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id  INTEGER NOT NULL,
        amount   INTEGER NOT NULL,
        status   TEXT    NOT NULL
    );
"""
)

cursor.execute(
    """
    CREATE TABLE IF NOT EXISTS outbox (
        id      INTEGER PRIMARY KEY AUTOINCREMENT,
        payload TEXT    NOT NULL,
        sent    INTEGER NOT NULL DEFAULT 0
    );
"""
)

conn.commit()

# -------------------------------------------------
#  Lightweight migration for old DB files
#  (adds the `sent` flag if it isn't there yet)

try:
    # Will raise sqlite3.OperationalError if the column already exists
    cursor.execute("ALTER TABLE outbox ADD COLUMN sent INTEGER DEFAULT 0;")
    conn.commit()
except sqlite3.OperationalError:
    # Column is already present – nothing to do
    pass
